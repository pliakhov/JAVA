/**
 * The Banking server initializes a remote object with the binding of myBanco
 * and creates a registry
 * 
 * @author Inna Zhogova, Paul Liakhov
 * 
 */
package server;

import org.finance.accounts.*;


public class BankingServer{

	public static void main(String[] args) {
		try {
			
			// Initialize the remote object
			BankingServiceImpl banco = new BankingServiceImpl();
			
			// Add accounts to the bank 
			GIC johnGic = new GIC("John Doe", "D1234","6000.00","0.015",2);
			Chequing johnChequing = new Chequing("John Doe", "E5678","15000.00", "0.75");
			Savings johnSavings = new Savings("John Doe", "F9801","8000.00", "0.0015");
			
			GIC maryGic = new GIC("Mary Ryan", "A1234", "15000.00", "0.025", 4);
			Chequing maryChequing = new Chequing("Mary Ryan", "B5678", "15000.00","0.75");
			Savings marySavings = new Savings("Mary Ryan", "C9012", "8000.00", "0.0015");
			
			banco.addAccount(johnGic);
			banco.addAccount(johnChequing);
			banco.addAccount(johnSavings);
			banco.addAccount(maryGic);
			banco.addAccount(maryChequing);
			banco.addAccount(marySavings);
			
			// Create RMI Registry 
			java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.createRegistry(5678);
			
			// Bind the object to the registry.
			registry.bind("myBanco", banco);
			
			
			System.out.println( "Server is Running!" );
			System.out.println( "Waiting for Client..." );
			
		}catch (Exception e) {
			
			e.printStackTrace();
		
		}// End of catch
	} // End of main
	
	
	
	
	
	
	
	
	
	
	
	
//	
//	
//	
//	
//	
//	public BankingServer(int portnum) 
//	{		
//	    try {
//			serverSocket = new ServerSocket( portnum );
//		} catch (IOException e) {
//            System.out.println( "I/O error in socket connection" );
//			e.printStackTrace();
//			// I/O error in socket connection
//		}         // create a server socket
//	    
//		isaac = new Bank("Paul Liakhov and Inna Zhogova");
//		loadBank(isaac);
//		clientCount = 0;
//	}
//	// C:\Users\Alexei\Documents\Buster
//	
//	public void startServer() 
//	{
//		LocalDateTime timePoint = LocalDateTime.now(); 
//		DateTimeFormatter date = DateTimeFormatter.ofPattern("MMMM d, yyyy");
//		DateTimeFormatter time = DateTimeFormatter.ofPattern("h:mm a ");
//		
//        loadBank(isaac);
//        
//        System.out.println("A BankServer instance is running! <"+time.format(timePoint) + date.format(timePoint)+">" );
//        
//	    while(true) {
//		    System.out.println( "listening for a connection..." );
//	        try {
//				socketConnection = serverSocket.accept();
//			} catch (IOException e) {
//				System.out.println( "I/O error in listening for connection" );
//				e.printStackTrace();
//			}  // listen and wait
//	        
//	        System.out.println( "start a thread for client #" + clientCount+1 );
//	    	System.out.println( "\t host name: " +
//	                                socketConnection.getInetAddress().getHostName() +
//	                            "\t IP address: " +
//	                                socketConnection.getInetAddress().getHostAddress() );
//	
//	        // System.out.println( "at port: " + socketConnection.getPort() );
//	    	Thread t = new HandleClientThread( socketConnection );
//        	t.start();
//        	clientCount++;
//        	
//        		        
//	    }
//	     
//	}
//	
//	/**
//	 * 
//	 * @param bank bank in which the accounts will be loaded into 
//	 */
//	public static void loadBank( Bank bank ) {
//		
//		
//		GIC johnGic = new GIC("John Doe", "D1234","6000.00","0.015",2);
//		Chequing johnChequing = new Chequing("John Doe", "E5678","15000.00", "0.75");
//		Savings johnSavings = new Savings("John Doe", "F9801","8000.00", "0.0015");
//		
//		
//		GIC maryGic = new GIC("Mary Ryan", "A1234", "15000.00", "0.025", 4);
//		Chequing maryChequing = new Chequing("Mary Ryan", "B5678", "15000.00","0.75");
//		Savings marySavings = new Savings("Mary Ryan", "C9012", "8000.00", "0.0015");
//		
//		bank.addAccount(johnGic);
//		bank.addAccount(johnChequing);
//		bank.addAccount(johnSavings);
//		bank.addAccount(maryGic);
//		bank.addAccount(maryChequing);
//		bank.addAccount(marySavings);
//		
//	}
//
//	class HandleClientThread extends Thread {
//
//        private Socket connection;
//
//        public HandleClientThread(Socket sock) { connection = sock; }
//
//        public void run() 
//        {
//        	boolean exit=false;
//        	/*connect input and output streams to the socket*/
//        	try 
//        	{
//        		DataOutputStream dosToClient = new DataOutputStream(socketConnection.getOutputStream());
//        		//dosToClient.flush();
//	       		DataInputStream  disFromClient = new DataInputStream(socketConnection.getInputStream());
//	       		ObjectOutputStream objToClient = new ObjectOutputStream(socketConnection.getOutputStream());	
//	       		ObjectInputStream objFromClient = new ObjectInputStream(socketConnection.getInputStream());
//	       		//objToClient.flush();
//	       		System.out.println( "I/O streams connected to the socket" );
//	       		/*exchange data with ONE client*/
//	       		String clientName = null;
//				clientName = (String) objFromClient.readObject();
//					        	         
//        	    System.out.println("+ name received: " + clientName );
//        	         
//        	        while (!exit) 
//        	            {
//        	        		// keep on getting data from the client
//        	        		 
//        	                int clientCommand = disFromClient.readInt();
//        			             // compute the area
//        	               
//        	                System.out.println(clientName +": command received: " + clientCommand);
//        	                  
//        	                  
//        	                switch(clientCommand) 
//        	                {
//        	                case 1:
//        	                	 //Send an array of all accounts
//        	                	 //objToClient.writeObject(isaac.sendAllAccounts());
//        	                break;
//        	                case 2:
//        	                	objToClient.writeObject("What is the balance?");
//        	                	 String balance = (String)objFromClient.readObject();
//        	                     System.out.println(clientName + ": balance received: " + balance);
//        	                     //Send an array of accounts with requested balance
//        	                     objToClient.writeObject(isaac.searchByBalance(new BigDecimal(balance)));
//        	                break;
//        	                case 0:
//        	                	 objToClient.writeObject("Thank You, " + clientName + "!");
//        	                	 
//        	                	 dosToClient.close();
//        	                	 disFromClient.close();
//        	                	 objFromClient.close();
//        	                	 objToClient.close();
//        	                	 connection.close();
//        	                	 exit=true;
//        	                break;
//        	                default:
//        	                break;
//        	                }
//        		          } 
//        	        	
//        	} catch (ClassNotFoundException | IOException e) {
//        		System.out.println("Exception thrown in a thread");
//				e.printStackTrace();
//			}// end while
//
//       } // end run
//
//    } // end HandleClientThread
}