/**
 * The BankingServiceImpl implements the BankingService Remote interface
 * and defines the methods set.
 * 
 * @author Inna Zhogova, Paul Liakhov
 * 
 */

package server;
import java.math.BigDecimal;

import org.finance.accounts.Account;

import common.BankingService;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;


public class BankingServiceImpl extends UnicastRemoteObject implements BankingService {


	private static final long serialVersionUID = 2858795963221527776L;
	
	private Bank m_bank;
	
	
	public BankingServiceImpl() throws RemoteException {
        super();
        m_bank = new Bank();
    }
	
	@Override
	/**
	 * removeAccount( String accountNumber )
	 * ----------------------------------
	 * Method to remove or close the account from the bank
	 * 
	 * @param accountNumber the identifier/account number of the account to be removed
	 * @return the account that has just been removed or NULL if it has not been removed
	 * @throws RemoteException
	 */
	public Account removeAccount(String accountNumber) throws RemoteException{
		return m_bank.removeAccount(accountNumber);
	}

	@Override
	/**
	 * searchByAccountNumber( String accountNumber )
	 * ---------------------------------------------
	 * Method to search for an account by number
	 * and return the corresponding account
	 * 
	 * @param accountNumber the identifier of the account
	 * @return the account found Null if not found
	 * @throws RemoteException
	 */
	public Account searchByAccountNumber(String accountNumber) throws RemoteException {
		return m_bank.searchByAccountNumber(accountNumber);
	}

	@Override
	/**
	 * searchByBalance(BigDecimal balance)
	 * ------------------------------------
	 * Method to search for an account by balance
	 * and return the corresponding account(s)
	 * 
	 * @param balance the balance to search for amongst accounts
	 * @return the accounts with the corresponding balance null if none are found
	 * @throws RemoteException
	 */
	public Account[] searchByBalance(BigDecimal balance)  throws RemoteException {
		return m_bank.searchByBalance(balance);
	}

	@Override
	/**
	 * searchByAccountName(String accountName )
	 * ----------------------------------------
	 * Method to search for accounts(s) by account holder's name
	 * and return the corresponding account(s)
	 * 
	 * @param accountName the name of the accounts to search by
	 * @return the account(s) with the corresponding name null if none are found
	 * @throws RemoteException
	 */
	public Account[] searchByAccountName(String accountName) throws RemoteException {
		return m_bank.searchByAccountName(accountName);
	}

	@Override
	/**
	 * getBankName()
	 * ----------------
	 * Method to return the bank name of the member bank
	 * 
	 * @return the bank name
	 * @throws RemoteException
	 */
	public String getBankName() throws RemoteException {
		return m_bank.getBankName();
	}

	@Override
	/**
	 * addAccount(Account newAccount)
	 * ------------------------------
	 * Method to add the parameter account into the bank
	 * 
	 * @param newAccount the account to be added or opened to the bank
	 * @return the status of the transaction, true if successful false if otherwise
	 * @throws RemoteException
	 */
	public boolean addAccount(Account newAccount) throws RemoteException {
		return m_bank.addAccount(newAccount);
	}
	
	@Override
	/**
	 * updateAccount( String accountNumber )
	 * --------------------------------------
	 * Method to update the account with the given accountNumber
	 * 
	 * @param accountNumber the identifier of the account to be updated
	 * @return the status of the update true if updated false if the updated failed
	 * @throws RemoteException
	 */
	public boolean updateAccount( String accountNumber) throws RemoteException {
		
		// Flag indicating the status of the transaction.
		boolean flag = false;
		
		String subOption;
		Account subTemp;
		String amount;
		
		
		// Initialize the scanner
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		// Get the account
		subTemp = m_bank.searchByAccountNumber(accountNumber);
		
		if(subTemp == null) {
			System.out.println("*** FAILED: ACCOUNT CANNOT BE FOUND! ***");
		}
		else {
			
		
			
			do {
				
				// FYI: The account has been found in the system 
				System.out.println("Please Enter:");
				System.out.println("a. Deposit Money.");
				System.out.println("b. Withdraw Money.");
				System.out.println("C. Exit.");
				
				subOption = keyboard.next();
				subOption.toUpperCase();
				
				switch(subOption) {	
					case "a":
						
						// Flush
						keyboard.nextLine();
						
						// Prompt the user for an amount
						System.out.print("Please enter the amount you would like to deposit: ");
						amount = keyboard.nextLine();
						
						// Set the amount to Deposit
						BigDecimal amBig = new BigDecimal(amount);
						
						// Deposit the amount into the account
						if(subTemp.deposit(amBig)) {
							
							// Display the updated account
							System.out.println("Account Updated");
							System.out.print(subTemp.toString());
							flag = true;
							
						}
					
					break;
					case "b":
						
						// Flush
						keyboard.nextLine();
						
						// Prompt the user for an amount
						System.out.print("Please enter the amount you would like to withdraw: ");
						amount = keyboard.nextLine();
						
						// Set the amount to withdraw
						amBig = new BigDecimal(amount);
						
						if(subTemp.withdraw(amBig)) {
						
							// Display the updated account
							System.out.println("Account Updated");
							System.out.print(subTemp.toString());
							flag = true;
							
						}
						break;
					case "c":
						subOption="c";
						break;
					default:
						System.out.println("ERROR: INVALID OPTION");
						break;
				}
			}while(subOption!="c");
		}
		return flag;
		
	}
	
	
}
