package server;

//Author: Paul Liakhov
//#: 108048166
//Date: 2018/02/06

import java.util.ArrayList;

import org.finance.accounts.Account;

import java.math.BigDecimal;

public class Bank {

	private String b_name;
	private ArrayList<Account> accounts;

	/**
	 * Default class constructor.
	 */
	public Bank() {
		
		// Default name is Seneca@York
		this.b_name = "Seneca@York";
		this.accounts = new ArrayList<Account>();
		
	}

	/**
	 * Class argument constructor 
	 * 
	 * @param bankName the name of the bank
	 */
	public Bank(String bankName) {
		
		// Initialize the bank name
		this.b_name = bankName;
		this.accounts = new ArrayList<Account>();
		
	}

	/**
	 * Function: addAccount()
	 * -----------------------
	 * Function to append account to
	 * the existing array of accounts.
	 * 
	 * @param newAccount the account to be added to the bank.
	 * @return the status of whether the account was added or not.
	 */
	public boolean addAccount(Account newAccount) {

		boolean flag = true;// Default assumes no existing accounts exist

		if (newAccount != null) {

			// Iterate through the array to check for Existing Accounts/Account Numbers
			for (int i = 0; i < this.accounts.size(); i++) {

				// If Accounts have the same number
				if (this.accounts.get(i).getAccountNumber() == newAccount.getAccountNumber()) {
					flag = false;
				}

			}

			// Add the account to bank
			if (flag == true) {
				accounts.add(newAccount);
			}

		} else {
			flag = false;
		}

		return flag;

	}

	public String getBankName() {
		return this.b_name;
	}

	/**
	 * Function: toString()
	 * --------------------
	 * Function to display the name of the bank 
	 * and the accounts of the bank. 
	 * 
	 * @return the bank information along with its respective accounts.
	 */
	public String toString() {

		String ts;

		ts = "*** Welcome to the Bank of " + 
		this.b_name + " ***\n" + "It has " + this.accounts.size() + " accounts.\n";

		for (int i = 0; i < accounts.size(); i++) {
			ts += i + 1 + ". number: " + this.accounts.get(i).getAccountNumber() + ", name: " + this.accounts.get(i).getFullName()
					+ ", balance: $" + this.accounts.get(i).getAccountBalance() + "\n";
		}
		return ts;
	}
	
	
	
	/**
	 * Function: equals
	 * ------------------
	 * Function to pass in an object and 
	 * return true, if the object passed in is of type 
	 * bank, 
	 * 
	 * @return the status of whether the Banks are the same.
	 */
	public boolean equals(Object e) {

		// Assumes everything is the same
		boolean flag = true;

		if (e instanceof Bank) {

			Bank Tes = (Bank) e;
			
			// Check that the two Banks have the same name 
			if (this.b_name == Tes.getBankName()) {

				// Iterate through both Banks checking that they have the Exact Same Accounts
				for (int i = 0; i < this.accounts.size(); i++) {

					
					if (!this.accounts.get(i).equals(Tes.accounts.get(i))) {
						flag = false;
					}

				}

			}
			else {
				
				// The names are not the same
				flag = false;
			
			}

		}
		else {
		
			// The object passed is not of type Bank
			flag = false;
		
		}
		
		return flag;

	}
	
	/**	Function: searchByBalance( int balance )
	 *  --------------------------
	 *  Function to pass in a balance,
	 *  search the bank for accounts 
	 *  with corresponding balance, and return
	 *  the respective array containing 
	 *  those balances.
	 *  
	 *  @param the balance to be used for searching. 
	 *  @return the accounts with the corresponding balance. 
	 *  
	 */
	public Account[] searchByBalance(BigDecimal balance) {

		int noMatch = 0;

		// To get the size of matches
		for (int i = 0; i < this.accounts.size(); i++) {

			if (this.accounts.get(i).getAccountBalance().compareTo(balance) == 0) {
				noMatch++;
			}

		}

		// Set the size of the array
		Account[] matches = new Account[noMatch];

		noMatch = 0;

		// Populating the Array
		for (int i = 0; i < accounts.size(); i++) {

			if (this.accounts.get(i).getAccountBalance().compareTo(balance) == 0) {
				matches[noMatch] = this.accounts.get(i);
				noMatch++;
			}

		}

		// No matches have been found
		if (noMatch == 0) {
			matches = new Account[0];
		}

		return matches;
	}
	
	/**
	 * Function to find accounts by given Account holder name.
	 * 
	 * @param accountName the name of the account's holder.
	 * @return the corresponding accounts under the account holder's name.
	 */
	public Account[] searchByAccountName(String accountName ) {

		int noMatch = 0;

		// To get the size of matches
		for (int i = 0; i < this.accounts.size(); i++) {

			if (this.accounts.get(i).getFullName().equals(accountName)) {
				noMatch++;
			}

		}

		// Set the size of the array
		Account[] matches = new Account[noMatch];

		noMatch = 0;

		// Populating the Array
		for (int i = 0; i < accounts.size(); i++) {

			if (this.accounts.get(i).getFullName().equals(accountName)) {
				matches[noMatch] = this.accounts.get(i);
				noMatch++;
			}

		}

		// No matches have been found
		if (noMatch == 0) {
			matches = new Account[0];
		}

		return matches;
	}
	
	/**
	 * Function to find an account by the given account number
	 * 
	 * @param accountNumber the number of the account to be searched for. 
	 * @return the account with the corresponding account(if successful null if not).
	 */
	public Account searchByAccountNumber( String accountNumber ) {
		
		// Set the default result to null(not found).
		Account match = null;
		
		// Search through the accounts
		for(int i = 0; i < accounts.size(); i++) {
			
			// Check if the account numbers are equal
			if(accounts.get(i).getAccountNumber().equals(accountNumber)) {
				match = 
				accounts.get(i);
			}
			
		}
		
		
		return match;
		
	}
	
	/**
	 * Function to list all the accounts in the bank
	 * 
	 */
	public void listAccounts() {
		
		// Iterate and display all accounts
		for(int i = 0; i < accounts.size(); i++) {
			System.out.println("---Account "+ (i+1) + ": ");
			System.out.print(accounts.get(i).toString());
		}
		
	}
	
	/**
	 * 
	 * @param accountNumber the number of the account to be removed
	 * @return the account that has been removed NULL if not. 
	 */
	public Account removeAccount( String accountNumber ) {
		
		// Set the default result of removal to null(false)
		Account match = null;
		
		// Search through the array for the account to remove.
		for(int i = 0; i < this.accounts.size(); i++) {
			
			if(this.accounts.get(i).getAccountNumber().equals(accountNumber)) {
				match = this.accounts.get(i);
				this.accounts.remove(i);
			}
		}
		 
		return match;
	}
	
	

}
