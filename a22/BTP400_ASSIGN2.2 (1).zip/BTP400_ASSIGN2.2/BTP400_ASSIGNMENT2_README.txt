BTP400 ASSIGNMENT #2.2

I Paul Liakhov, and Inna Zhogova have worked together on this assignment.

Work allocated as follows.

Inna Zhogova-

-BankingService.java
-BankingServiceImpl.java
-BankingServer.java

Paul Liakhov

-RemoteBankClient.java
-BankingServer.java


1: Extraction:
jar xf commonjar\bankingservice.jar
jar xf commonjar\accounts.jar

2: Compilation:
-- server
javac server\BankingServer.java
-- client
javac client\RemoteBankClient.java

3:Execution:
-- server
java server.BankingServer
--client
java client.RemoteBankClient

