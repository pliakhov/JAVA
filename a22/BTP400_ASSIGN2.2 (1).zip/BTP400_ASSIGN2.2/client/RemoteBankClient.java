/**
 * The RemoteBankClient provides the user with a menu and various options to use the functionality of 
 * the bank.
 * 
 * @author Inna Zhogova, Paul Liakhov
 * 
 */

package client;

import java.math.BigDecimal;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.finance.accounts.*;

import common.BankingService;


/**
@author Paul Liakhov
**/
public class RemoteBankClient {
	
	public static void main(String[] args) throws RemoteException, NotBoundException {
		
		
		try {
		
		System.out.println("Instance is running!");
		
		
		// Registry create and locate to interact with server
		java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.getRegistry(5678);
		
		// Create the remote bank object to use via RMI
		BankingService bank = (BankingService) registry.lookup("myBanco");
		
		// Scanner to read in user input
		Scanner keyboard = new Scanner(System.in);
		
		// Menu choice of the user
		int choice = 0;
		
		// Account identifier
		String accountNumber;
		
		// Create string for menu, timePoint for current time and datePoint likewise.
		String ts;
		String timePoint = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm a")); 
		String datePoint = LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy")); 
		
		
		// String to be used for the menu
		ts =
				"### Welcome to the Bank of "+ bank.getBankName() + " ###" + "\n" +
				timePoint +" " +datePoint
				+ "\n" 
				+"1. Open an account."+ "\n"
				+"2. Close an account."+ "\n"
				+"3. Update an account."+ "\n"
				+"4. Search."+ "\n"
				+"5. List all accounts."+ "\n"
				+"6. Exit."+ "\n"+
				"Please enter your choice: ";
				
		
		
		   
			do {
				
				// Output the Menu. 
				System.out.print(ts);
				
				// Read the choice
				choice = keyboard.nextInt();
				System.out.println("");
				
				switch(choice) {
				
				// Create an Account and Add it to the bank. 
				case 1:
					
					
					// Tokens for adding and creating an account in the bank
					String []fields;
					
					
					// Prompt the user for the account Information
					System.out.println("Please enter information(e.g. account type, name,");
					System.out.println("account number, balance, interest rate ) at one line:");
					keyboard.nextLine();
					
					String input = keyboard.nextLine();
					
					fields =  input.split("\\s*,\\s*");
					
					// Account that is to be added to the bank
					Account temp = null;
					
					// Account Number is already assigned
					if( bank.searchByAccountNumber(fields[2]) == null ) {
						
						// verify account and create account according to type.
						if(fields[0].equals("SAV")) {
						
							if( bank.searchByAccountNumber(fields[2]) == null )
								temp = new Savings(fields[1],fields[2],fields[3],fields[4]);
						
							
						}
						else if(fields[0].equals("CHQ")) {
						
							temp = new Chequing(fields[1],fields[2],fields[3],fields[4]);
						
						}
						else if(fields[0].equals("GIC")) {
						
							temp = new GIC(fields[1],fields[2],fields[3],fields[4],Integer.parseInt(fields[5]));
						
						}
						else {
							temp = new Account(fields[1],fields[2],fields[3]);
						}
					
						// Add the account to the bank
						if(bank.addAccount(temp) == true) { 
						
							System.out.println("+ Account Opened: ");
						
							// Show the added account
							temp.toString();
					
						}
						else {
					
							// The account could not be added
							System.out.println("*** FAILED: ACCOUNT CANNOT BE OPENED! ***");
					
						}
					}
					else {
						// The account could not be added
						System.out.println("*** FAILED: ACCOUNT IS ALREADY IN USE ***");
						System.out.println("*** FAILED: ACCOUNT CANNOT BE OPENED! ***");
					}
					
					break;
					
				// Remove an account from the bank
				case 2:
					
					

					// Prompt the user for the account # of the account to remove.
					System.out.println("Please enter the account number of the account you would like to remove:");
					
					// Flush the scanner
					keyboard.nextLine();
					
					accountNumber = keyboard.nextLine();
					
					if(bank.searchByAccountNumber(accountNumber) != null) {
						// Account has been successfully closed
						System.out.println("+ Account Closed: ");
						System.out.print((bank.removeAccount(accountNumber)).toString());
					}
					else {
						System.out.println("*** FAILED: ACCOUNT CANNOT BE CLOSED! ***");
					}
					
					
					break;
					
				// Update an account
				case 3:
					
					
					System.out.println("Please enter your Acct #:");
					keyboard.nextLine();
					accountNumber = keyboard.nextLine();

						// Indicate that the account could not be updated
					if(!bank.updateAccount(accountNumber)) {
						System.out.println("*** FAILED: ACCOUNT CANNOT BE FOUND! ***");
					}
					
					break;
					
				// Search the bank for the account
				case 4:
					
					String subOption1;
					
					BigDecimal search_M;
					String accNo;
					System.out.println("a. Search by account balance.");
					System.out.println("b. Search by account name.");	
					System.out.println("c. Search by account number.");
					subOption1 = keyboard.next();
					Account result;
					Account [] results;
					
					switch(subOption1) {	
					case "a":
						System.out.println("Please enter the balance: ");
						search_M = keyboard.nextBigDecimal();
						results = bank.searchByBalance(search_M);
						
						if(results.length > 0) {
							System.out.println("Account Retrieved.");
							// Display the results
							for(int i = 0; i < results.length; i++) {
								System.out.println("---- Account "+(i+1));
								System.out.print(results[i].toString());
							}
						}
						else {
							System.out.println("*** FAILED: ACCOUNT CANNOT BE RETRIEVED! ***");
						}
						
					break;
					case "b":
						keyboard.nextLine();
						System.out.println("Please enter the account name: ");
						String accName = keyboard.nextLine();
						
						results = bank.searchByAccountName(accName);
						
						// Display the result 
						if(results.length > 0) {
							System.out.println("Account Retrieved.");
							// Display the results
							for(int i = 0; i < results.length; i++) {
								System.out.println("---- Account "+(i+1));
								System.out.print(results[i].toString());
							}
						}
						else {
							System.out.println("*** FAILED: ACCOUNT CANNOT BE RETRIEVED! ***");
						}
						
					break;
					case "c":
						keyboard.nextLine();
						System.out.println("Please enter the account Number: ");
						accNo = keyboard.nextLine();
						
						result = bank.searchByAccountNumber(accNo);
						
						// Display the result
						if( result != null) {
							System.out.println("Account Retrieved.");
							System.out.print(result.toString());
						}
						else {
							System.out.println("*** FAILED: ACCOUNT CANNOT BE RETRIEVED! ***");
						}
					break;
					}
					
					break;
				case 5:
					
					System.out.println(" List accounts is unavailable for this client!");
					
					break;
				case 6:
					
					break;
				default:
					System.out.println("Invalid Input Please Select a valid selection");
					break;
				}
				
				
			} while( choice != 6);
		   keyboard.close();
		   
		   System.out.println("RMI CLIENT HAS STOPPED.");
		   
		}
		 catch( Exception e ) {
			 System.out.println( "Error " + e );
	   }
		
		
		

}
	
	
	
	
	
	
	
	
	
	
		
//	public static void main(String[] args) {
//	
//	// Instantiate the socket
//	Socket clientSocket;
//	
//	// Greet the user 
//	System.out.println("Welcome to the Bank of Paul Liakhov and Inna Zhogova!");
//	System.out.println("Instance is running!");
//	
//	try {
//		
//		// Connect to the server
//		 clientSocket = new Socket( InetAddress.getByName( "localhost" ), Integer.parseInt(args[0]));
//		 System.out.println( "Connected to " +
//                 clientSocket.getInetAddress().getHostName() );
//		// Connect to the server
//		//		 clientSocket = new Socket( InetAddress.getByName( "localhost" ),
//		//				 8000   );
//		 // Stream to send output to the server. 
//		 DataInputStream dosFromServer = new DataInputStream( clientSocket.getInputStream() );
//		 DataOutputStream dosToServer = new DataOutputStream( clientSocket.getOutputStream() );
//		 //dosToServer.flush();
//		 // Stream to send input to the server. 
//	     ObjectInputStream objFromServer = new ObjectInputStream(clientSocket.getInputStream());
//	     ObjectOutputStream objToServer = new ObjectOutputStream(clientSocket.getOutputStream());
//	     //objToServer.flush();
//		 Scanner keyboard = new Scanner( System.in );
//		
//		 System.out.print("Enter your name: ");
//		 String name = keyboard.nextLine();
//		 // STEP 2: Send the name to the server
//		 objToServer.writeObject(name);
//		 // Flush the data
//		 objToServer.flush();
//		 
//		 // Create the choice.
//		 int choice = 0;
//		 
//		 // Flush the keyboard
//		 
//		 String ts;
//			String timePoint = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm a")); 
//			String datePoint = LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy")); 
//			ts =
//					"### Welcome to the Bank of "+ name+" ###" + "\n" +
//					timePoint +" " +datePoint
//					+ "\n" 
//					+"1. Open an account."+ "\n"
//					+"2. Close an account."+ "\n"
//					+"3. Update an account."+ "\n"
//					+"4. Search."+ "\n"
//					+"5. List all accounts."+ "\n"
//					+"6. Exit."+ "\n"+
//					"Please enter your choice: ";
//					
//			
//		 
//		 do {
//			 
//			 // Question do we want to display from client immediately or get the menu from server??
//				
//			 // Prompt the user for a command
//			 System.out.print(ts);
//		 	choice = keyboard.nextInt();
//		 
//		 	// Send choice to server
//		 	dosToServer.writeInt(choice);
//		 	
//		 	// Data sent immediately
//		 	dosToServer.flush();
//		 	
//		 	if(choice == 0) {
//		 		
//		 		// Send finished message and close 
//		 		String lpl = (String)objFromServer.readObject();
//		 		System.out.println(lpl);
//		 		
//		 		dosToServer.close();
//		 		dosFromServer.close();
//		 		objFromServer.close();
//		 		objToServer.close();
//		 		clientSocket.close();
//		 	
//		 	}else if(choice == 1) {
//		 		
//		 		
//		 		 Account accounts[] = new Account[100];
//		 		 try {
//						accounts = (Account[])objFromServer.readObject();
//					} catch (ClassNotFoundException e) {
//						e.printStackTrace();
//					}
//		 		 
//		 		 boolean flag = false;
//		 		 int amountOfAcc = accounts.length;
//		 		 
//		 		 //Count the number of accounts
//		 		 for(int i = 0; i < accounts.length && flag == false; i++) {
//		 			 if(accounts[i] == null) {
//		 				 flag = true;
//		 				 amountOfAcc = i;
//		 			 }
//		 			 
//		 		 }
//		 		 
//		 		 
//		 		 // Display all accounts
//		 		 for(int i = 0; i < amountOfAcc; i ++) {
//		 			 System.out.println(i+1 + ". " + accounts[i].toString());
//		 			 
//		 		 }
//		 		 
//		 	}
//		 	else if(choice == 2) {
//		 		
//		 		// Read the server message
//		 		String message = null;
//				try {
//					message = (String) objFromServer.readObject();
//				} catch (ClassNotFoundException e) {
//					e.printStackTrace();
//				}
//		 		
//		 		// Display the server message
//		 		System.out.println("# question from the server: " + message);
//				System.out.print(">");
//
//		 		BigDecimal response = keyboard.nextBigDecimal();
//		 		
//		 		// Send the amount(string)
//		 		objToServer.writeObject(response.toString());
//		 		 Account accounts[] = new Account[100];
//		 		 try {
//					accounts = (Account[])objFromServer.readObject();
//				} catch (ClassNotFoundException e) {
//					e.printStackTrace();
//				}
//		 		if(accounts != null) {
//		 	       // Display all accounts
//		 	       for(int i = 0; i < accounts.length; i ++) {
//		 	        // This toString also needs to BE CHANGED DO NOT LEAVE IT!!!!!!!!
//		 	        System.out.println(i+1 + ". " + accounts[i].toString());
//		 	        
//		 	       }
//		 	      } 
//		 	      else System.out.println("No accounts were found");		 		
//		 		
//		 	}
//		 
//		 }while(choice !=0);
//		 
//		 keyboard.close();
//	}
//	catch( IOException ioe ) { 
//		
//		// Display the Error. 
//		System.out.println( "I/O errors in socket connection" );
//		ioe.printStackTrace(); 
//    
//	} catch (ClassNotFoundException e) {
//		System.out.println("Didn't receive a goodbye");
//		e.printStackTrace();
//	}
//	
//	System.out.println( "... the client is going to stop running..." );
//	
//	}
}